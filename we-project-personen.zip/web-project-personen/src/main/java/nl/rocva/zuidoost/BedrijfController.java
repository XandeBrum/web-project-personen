package nl.rocva.zuidoost;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class BedrijfController {

	@GetMapping("/onsbedrijf")
	public String onsBedrijf(Model model) {
		
		//Persoon persoon = new Persoon("Chiel");

		
		return "ons-bedrijf";
	}

}

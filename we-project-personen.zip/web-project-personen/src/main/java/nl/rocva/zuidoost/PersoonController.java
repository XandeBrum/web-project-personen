package nl.rocva.zuidoost;

import java.util.List;
import java.util.ArrayList;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@Controller
public class PersoonController {

	@GetMapping("/personen")
	public String showPersoonOverzicht(Model model) {
		
		Persoon ron = new Persoon("S12345", "Ron", "Jansen", 18);
		Persoon yara = new Persoon("S22345", "Yara", "Pereira", 19);
		  
		List<Persoon> personen = new ArrayList<Persoon>();
		
		personen.add(ron);
		personen.add(yara);
		
		model.addAttribute("persoon", personen);
		
		return "personen";
		
	}
	@GetMapping("/personen/{id}")
	public String showPersoonDetails(@PathVariable String id, Model model) {
		
		Persoon yara = new Persoon("S22345", "Yara", "Pereira", 19);
		
		model.addAttribute("persoon", yara);
		
		return "persoon-detail";
		
	}
}
